INSERT INTO DB4BikeStore_brands(brand_id,brand_name) VALUES(1,'Electra');
INSERT INTO DB4BikeStore_brands(brand_id,brand_name) VALUES(2,'Haro');
INSERT INTO DB4BikeStore_brands(brand_id,brand_name) VALUES(3,'Heller');
INSERT INTO DB4BikeStore_brands(brand_id,brand_name) VALUES(4,'Pure Cycles');
INSERT INTO DB4BikeStore_brands(brand_id,brand_name) VALUES(5,'Ritchey');
INSERT INTO DB4BikeStore_brands(brand_id,brand_name) VALUES(6,'Strider');
INSERT INTO DB4BikeStore_brands(brand_id,brand_name) VALUES(7,'Sun Bicycles');
INSERT INTO DB4BikeStore_brands(brand_id,brand_name) VALUES(8,'Surly');
INSERT INTO DB4BikeStore_brands(brand_id,brand_name) VALUES(9,'Trek');